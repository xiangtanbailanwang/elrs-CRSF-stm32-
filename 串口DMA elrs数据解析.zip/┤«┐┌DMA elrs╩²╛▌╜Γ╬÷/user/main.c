#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "Serial.h"
#include "DMA.h"
#include "EXTI.h"
uint16_t ch1;
uint16_t ch2;
uint16_t ch3;
uint16_t ch4;
uint16_t ch5;
uint16_t ch6;
uint16_t ch7;
uint16_t ch8;
int main(void)
{
	OLED_Init();
	Serial_INIT();
	Dma_init();
	MYNVIC_INIT();
	
	while(1)
	{
		ch1 = ((DataA[3]>>0) | (DataA[4]<<8)) & 0x07FF;
		ch2 = ((DataA[4]>>3) | (DataA[5]<<5)) & 0x07FF;
		ch3 = ((DataA[5]>>6) | (DataA[6]<<2) | (DataA[7]<<10)) & 0x07FF;
		ch4 = ((DataA[7]>>1) | (DataA[8]<<7)) & 0x07FF;
		ch5 = ((DataA[8]>>4) | (DataA[9]<<4)) & 0x07FF;
		ch6 = ((DataA[9]>>7) | (DataA[10]<<1)|(DataA[11]<<9)) & 0x07FF;		
		ch7 = ((DataA[11]>>2) | (DataA[12]<<6)) & 0x07FF;		//ʣ3
		ch8 = ((DataA[12]>>5) | (DataA[13]<<3)) & 0x07FF;

		OLED_ShowNum(1,1,ch1,4);
		OLED_ShowNum(2,1,ch2,4);
		OLED_ShowNum(3,1,ch3,4);
		OLED_ShowNum(4,1,ch4,4);
		OLED_ShowNum(1,6,ch5,4);
		OLED_ShowNum(2,6,ch6,4);
		OLED_ShowNum(3,6,ch7,4);
		OLED_ShowNum(4,6,ch8,4);
	}

}



