#ifndef __EXTI_H
#define __EXTI_H

#include "stm32f10x.h"                  // Device header

void MYNVIC_INIT(void);

#endif
