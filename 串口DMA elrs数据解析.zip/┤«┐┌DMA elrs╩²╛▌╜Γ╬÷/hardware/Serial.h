#ifndef __SERIAL_H
#define __SERIAL_H
#include "stm32f10x.h"                  // Device header

extern uint8_t break_circulation;
extern uint8_t Serial_txpacket[];
extern uint8_t Serial_Rxpacket[];
void Serial_INIT(void);
void SERIAL_SENT_Byte(uint8_t byte);
void SERIAL_SENT_MY_ARRY(uint8_t *arry);
void SERIAL_SENT_STRING(char *mystr);
void SERIAL_SENT_NUMBER(uint32_t NUMBER,uint8_t LENGTH);
void serial_printf(char *format,...);
uint8_t serial_getrxflage(void);
void serial_Sentpacket(void);


#endif

