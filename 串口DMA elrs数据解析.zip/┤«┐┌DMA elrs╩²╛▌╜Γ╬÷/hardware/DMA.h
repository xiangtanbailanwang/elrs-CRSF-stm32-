#ifndef __DMA_H
#define __DMA_H

#include "stm32f10x.h"                  // Device header
extern uint8_t DataA[26];
extern uint8_t SIZEBUFF;

void Dma_init();
void dma_goon();


#endif
